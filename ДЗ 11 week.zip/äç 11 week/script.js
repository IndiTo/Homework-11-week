


function applyDiscount() {
    
}
const applyDiscount = () => {
    const items = document.getElementsByName(.item).value;
    const summ = items[0].value + items[1].value + items[2].value + items[3].value;
    console.log(summ);
    
}
applyDiscount()